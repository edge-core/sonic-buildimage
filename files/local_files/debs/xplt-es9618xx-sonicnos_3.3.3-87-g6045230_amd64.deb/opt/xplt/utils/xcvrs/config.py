#!/opt/xplt/venv/bin/python
# SPDX-License-Identifier: MIT
#
# Copyright (c) 2020 Xsightlabs Ltd.

import argparse
import time
import sys
import os
from vendor_info import part_numbers, app_dict

config_modes = [
    'One config for all at once',
    'All configs one by one'
]

breakout_modes = [
    '8H800-8M800',
    '4H400-4M400',
    '2H200-2M200',
    '1H100-1M100',
    '8H400-8M400',
    '4H200-4M200',
    '2H100-2M100',
    '1H50-1M50'
]

parser = argparse.ArgumentParser(description='Configure supported optical modules',
                                 formatter_class=argparse.RawTextHelpFormatter)
parser.add_argument('first',
                    type=int,
                    nargs='?',
                    default=1,
                    help = 'the front panel first port number to configure')

parser.add_argument('last',
                    type=int,
                    nargs='?',
                    default=32,
                    help = 'the front panel last port number to configure')

parser.add_argument('-u',
                    '--url',
                    type=str,
                    help='hostname or IP address of the oomjsonsvr server')

parser.add_argument('-s',
                    '--standalone',
                    action='store_true',
                    help='standalone mode')

parser.add_argument('--skipfir',
                    action='store_true',
                    help='do not configure FIR profile')

parser.add_argument('-m',
                    '--mode',
                    type=int,
                    choices=[i for i in range(1, (len(config_modes) + 1))],
                    help =''.join('[{}] - {}\n'.format(i + 1, config_modes[i])
                                   for i in range(len(config_modes))))

parser.add_argument('-b',
                    '--breakout',
                    default=4,
                    type=int,
                    choices=[i for i in range(1, (len(breakout_modes) + 1))],
                    help =''.join('[{}] - {}\n'.format(i + 1, breakout_modes[i])
                                   for i in range(len(breakout_modes))))

parser.add_argument('-v',
                    '--verbose',
                    action='count',
                    default=0,
                    help='more verbose print')

args = parser.parse_args()

if args.standalone:
    import oom
    if args.url != None:
        oom.oomlib.setshim("oomjsonshim", args.url)
else:
    try:
        import oomlwclient as oom
        oom.oomlwclient_init(args.url)
    except:
        if args.verbose > 0:
            print("Running in standalone mode")
        import oom
        if args.url != None:
            oom.oomlib.setshim("oomjsonshim", args.url)

# We do not configure the FIR (profile) by default.
# To configure module's FIR, add its part number to this list.
set_fir_modules = []

profiles = {
    '1064281000': {
        '8H800-8M800': (50, 0),
        '4H400-4M400': (50, 0),
        '2H200-2M200': (50, 0),
        '1H100-1M100': (50, 0),
        '8H400-8M400': (50, 0),
        '4H200-4M200': (50, 0),
        '2H100-2M100': (50, 0),
        '1H50-1M50':   (50, 0)
    },
    '2253611007': {
        '8H800-8M800': (50, 0),
        '4H400-4M400': (50, 0),
        '2H200-2M200': (50, 0),
        '1H100-1M100': (50, 0),
        '8H400-8M400': (50, 0),
        '4H200-4M200': (50, 0),
        '2H100-2M100': (50, 0),
        '1H50-1M50':   (50, 0)
    },
    'T-DP4CNH-N00': {
        '8H800-8M800': (50, 0),
        '4H400-4M400': (50, 0),
        '2H200-2M200': (50, 0),
        '1H100-1M100': (50, 0),
        '8H400-8M400': (50, 0),
        '4H200-4M200': (50, 0),
        '2H100-2M100': (50, 0),
        '1H50-1M50':   (50, 0)
    },
    'T-OP8CDT-N00': {
        '8H800-8M800': (106, 0),
        '4H400-4M400': (106, 0),
        '2H200-2M200': (106, 0),
        '1H100-1M100': (106, 0),
        '8H400-8M400': (106, 0),
        '4H200-4M200': (106, 0),
        '2H100-2M100': (106, 0),
        '1H50-1M50':   (106, 0)
    },
    'CAC82X321M1MB0HW': {
        '8H800-8M800': (50, 0),
        '4H400-4M400': (50, 0),
        '2H200-2M200': (50, 0),
        '1H100-1M100': (50, 0),
        '8H400-8M400': (50, 0),
        '4H200-4M200': (50, 0),
        '2H100-2M100': (50, 0),
        '1H50-1M50':   (50, 0)
    },
    'CAC825321A1AC0HW': {
        '8H800-8M800': (85, 7),
        '4H400-4M400': (85, 5),
        '2H200-2M200': (85, 3),
        '1H100-1M100': (85, 1),
        '8H400-8M400': (85, 7),
        '4H200-4M200': (85, 5),
        '2H100-2M100': (85, 3),
        '1H50-1M50':   (85, 1)
    },
    'T-OS8CNS-N00': {
        '8H800-8M800': (106, 9),
        '4H400-4M400': (106, 9),
        '2H200-2M200': (106, 9),
        '1H100-1M100': (106, 9),
        '8H400-8M400': (106, 11),
        '4H200-4M200': (106, 12),
        '2H100-2M100': (106, 13),
        '1H50-1M50':   (106, 13)
    },
    'T-OH8CNH-N00': {
        '8H800-8M800': (106, 9),
        '4H400-4M400': (106, 7),
        '2H200-2M200': (106, 8),
        '1H100-1M100': (106, 8),
        '8H400-8M400': (106, 3),
        '4H200-4M200': (106, 3),
        '2H100-2M100': (106, 3),
        '1H50-1M50':   (106, 3)
    },
    '2476103-5': {
        '8H800-8M800': (106, 1),
        '4H400-4M400': (106, 3),
        '2H200-2M200': (106, 3),
        '1H100-1M100': (106, 3),
        '8H400-8M400': (106, 5),
        '4H200-4M200': (106, 6),
        '2H100-2M100': (106, 6),
        '1H50-1M50':   (106, 6)
    },
    'ET8001-SR8': {
        '8H800-8M800': (106, 1),
        '4H400-4M400': (106, 2),
        '2H200-2M200': (106, 3),
        '1H100-1M100': (106, 4),
        '8H400-8M400': (106, 4),
        '4H200-4M200': (106, 4),
        '2H100-2M100': (106, 4),
        '1H50-1M50':   (106, 4)
    }
}

plats = ["es9618xx", "x2-128-o"]
calib = "/opt/xplt/utils/xcvrs/calib.py"
ports = 32

if args.standalone:
    calib = calib + " -s"

with open('/opt/xplt/xplt') as f:
    for plat in plats:
        if plat in f.read():
            ports = 16
            if args.last > ports:
                args.last = ports

def main():
    first = args.first
    last  = args.last
    if first < 1 or first > ports or last < first or last > ports:
        print("Invalid port number")
        sys.exit(1)

    portlist = oom.oom_get_portlist()
    if len(portlist) == 0:
        print("Empty portlist, configuration issue?")
        exit()

    brkout = breakout_modes[args.breakout - 1]
    if args.verbose > 0: print(brkout)

    if args.mode == 1:
        pn = "T-OS8CNS-N00"
        pni = 8 # P/N index in part_numbers list, starting from 1
        rng = last - first + 1
        if args.skipfir or pn not in set_fir_modules:
            cmds = [
                "sudo {} {} -R {} --PN {} -u".format(calib, first, rng, pni),
                "sudo {} {} -R {} --PN {} --set_app {}".format(calib, first, rng, pni, profiles[pn][brkout][1]),
                "sudo {} {} -R {} --PN {} -l 4 0xff off".format(calib, first, rng, pni)
            ]
        else:
            cmds = [
                "sudo {} {} -R {} --PN {} -u".format(calib, first, rng, pni),
                "sudo {} {} -R {} --PN {} -p {}".format(calib, first, rng, pni, profiles[pn][brkout][0]),
                "sudo {} {} -R {} --PN {} --set_app {}".format(calib, first, rng, pni, profiles[pn][brkout][1]),
                "sudo {} {} -R {} --PN {} -l 4 0xff off".format(calib, first, rng, pni)
            ]
        for idx, cmd in enumerate(cmds):
            if args.verbose == 2: print(cmd)
            a = os.popen(cmd).read()
            if idx == 0: time.sleep(1)
            if args.verbose > 0: print(a)
    else:
        first -= 1
        for i in range (first, last):
            port = portlist[i]
            modtype = oom.type_to_str(port.port_type)
            if modtype == 'UNKNOWN':
                modtype = 'No Module'
            pi = i + 1
            v_pn = oom.oom_get_keyvalue(port, 'VENDOR_PN')
            for pn in part_numbers:
                if pn.split() == v_pn.split():
                    a = os.popen("sudo {} {} -u".format(calib, pi)).read()
                    if args.verbose > 0: print(a)
                    time.sleep(1)
                    if not args.skipfir and pn in set_fir_modules:
                        a = os.popen("sudo {} {} -p {}".format(calib, pi, profiles[pn][brkout][0])).read()
                        if args.verbose > 0: print(a)
                    if profiles[pn][brkout][1] != 0:
                        a = os.popen("sudo {} {} --set_app {}".format(calib, pi, profiles[pn][brkout][1])).read()
                        if args.verbose > 0: print(a)
                    a = os.popen("sudo {} {} -l 4 0xff off".format(calib, pi)).read()
                    if args.verbose > 0: print(a)

if __name__ == "__main__":
    main()
