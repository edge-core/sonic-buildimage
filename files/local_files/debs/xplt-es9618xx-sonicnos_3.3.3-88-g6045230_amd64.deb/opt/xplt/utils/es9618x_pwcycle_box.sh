#!/bin/bash
#
# SPDX-License-Identifier: MIT
#
# Copyright (c) 2020 Xsightlabs Ltd.

fname=$(basename $0)

function klog {
	echo "$fname:" "$@" | tee /dev/kmsg
}

adapter='SMBus I801 adapter'
found=0
for I2CBUS in 0 1; do
	devname=`cat /sys/bus/i2c/devices/i2c-$I2CBUS/name`
	if [[ $devname == $adapter* ]]; then
		klog "$adapter = $I2CBUS"
		found=1
		break
	fi
done
if [ $found -eq 0 ]; then
	klog "Cannot find $adapter"
	exit 1
fi

CONFIG_DB=/etc/sonic/config_db.json
if [ -f $CONFIG_DB ]; then
	docker > /dev/null 2>&1
	if [ $? -eq 0 ]; then
		SHUTDOWN="/usr/sbin/shutdown -H now"
	else
		SHUTDOWN="echo o > /proc/sysrq-trigger"
	fi
else
	SHUTDOWN="/sbin/shutdown -H now"
fi

fpga_major_ver=$(i2cget -y -f $I2CBUS 0x68 0x1)
if [ $? -ne 0 ]; then
	klog "Failed to access FPGA"
	exit 1
fi
fpga_minor_ver=$(i2cget -y -f $I2CBUS 0x68 0x2)
fpga_ver=$(printf "%d.%d" $fpga_major_ver $fpga_minor_ver)
klog "FPGA ver: $fpga_ver"

klog "Power cycling the switch in 70 seconds..."
sleep 2
# Set FPGA 0x60 [1]=0 to start 60s countdown to power cycle 12V
set -x
i2cset -y -f $I2CBUS 0x68 0x60 0x11

#Shutdown OS within 60s
eval $SHUTDOWN
