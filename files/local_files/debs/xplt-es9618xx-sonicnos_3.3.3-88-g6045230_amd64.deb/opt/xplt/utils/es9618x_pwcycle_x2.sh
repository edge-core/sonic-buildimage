#!/bin/bash
#
# SPDX-License-Identifier: MIT
#
# Copyright (c) 2024 Xsightlabs Ltd.

fname=$(basename $0)

function klog {
	echo "$fname:" "$@" | tee /dev/kmsg
}

adapter='SMBus I801 adapter'
found=0
for I2CBUS in 0 1; do
	devname=`cat /sys/bus/i2c/devices/i2c-$I2CBUS/name`
	if [[ $devname == $adapter* ]]; then
		klog "$adapter = $I2CBUS"
		found=1
		break
	fi
done
if [ $found -eq 0 ]; then
	klog "Cannot find $adapter"
	exit 1
fi

# Compares $1 and $2 strings of numbers separed by dotes
# Returns: 0 for == ; 1 for > ; 2 for <
function compare_versions {
	local a=${1%%.*} b=${2%%.*}
	[[ "10#${a:-0}" -gt "10#${b:-0}" ]] && return 1
	[[ "10#${a:-0}" -lt "10#${b:-0}" ]] && return 2
	a=${1:${#a} + 1} b=${2:${#b} + 1}
	[[ -z $a && -z $b ]] || compare_versions "$a" "$b"
}

fpga_ver=$(cat /sys/bus/i2c/devices/1-0068/version)
compare_versions $fpga_ver 4.0
if (( $? == 2 )); then
	klog "Unsupported FPGA version $fpga_ver"
	exit 1
fi

lsmod | grep xpci > /dev/null
if [ $? -eq 0 ]; then
	echo "$fname: Unload xpci module"
	systemctl list-unit-files | grep xmon > /dev/null
	if [ $? -eq 0 ]; then
		systemctl stop xmon.service
		sleep 3
	fi
	rmmod xpci
	res=$?
	sleep 3
	if [ $res -eq 1 ]; then
		klog "Failed to unload xpci module"
		exit 1
	fi
fi

klog "Power cycle X2 ..."

trap 'echo -e "\nIgnore Ctrl-C"' SIGINT

#### X2 chip VRM Power-off sequence
# Mask CPU reset pin and release X2 chip protection
i2cset -f -y $I2CBUS 0x68 0x48 0x00
i2cget -f -y $I2CBUS 0x68 0x48
# Mask MB reset pin
i2cset -f -y $I2CBUS 0x68 0x0c 0x3e
i2cget -f -y $I2CBUS 0x68 0x0c
# Mask MB reset pin
i2cset -f -y $I2CBUS 0x68 0x0d 0x1f
i2cget -f -y $I2CBUS 0x68 0x0d
# Mask MB reset pin
i2cset -f -y $I2CBUS 0x68 0x0e 0x1f
i2cget -f -y $I2CBUS 0x68 0x0e
# Reset X2 chip
i2cset -f -y $I2CBUS 0x68 0x08 0x3f
i2cget -f -y $I2CBUS 0x68 0x08
# Disable GROUP1, GROUP2, GROUP3 and GROUP3-1 powers
i2cset -f -y $I2CBUS 0x68 0x61 0xc3
i2cget -f -y $I2CBUS 0x68 0x61

#### X2 chip VRM Power-on sequence
# Enable GROUP1 group power
i2cset -f -y $I2CBUS 0x68 0x61 0xe3
i2cget -f -y $I2CBUS 0x68 0x61
# Enable GROUP2 group power
i2cset -f -y $I2CBUS 0x68 0x61 0xf3
i2cget -f -y $I2CBUS 0x68 0x61
# Enable GROUP3, GROUP3-1 group power
i2cset -f -y $I2CBUS 0x68 0x61 0xff
i2cget -f -y $I2CBUS 0x68 0x61
# Release reset X2 chip
i2cset -f -y $I2CBUS 0x68 0x08 0xbf
sleep 1
i2cget -f -y $I2CBUS 0x68 0x08
# Release mask CPU reset pin and X2 chip protection
i2cset -f -y $I2CBUS 0x68 0x48 0x60
i2cget -f -y $I2CBUS 0x68 0x48
# Release mask MB reset pin
i2cset -f -y $I2CBUS 0x68 0x0c 0x00
i2cget -f -y $I2CBUS 0x68 0x0c
# Release mask MB reset pin
i2cset -f -y $I2CBUS 0x68 0x0d 0x00
i2cget -f -y $I2CBUS 0x68 0x0d
# Release mask MB reset pin
i2cset -f -y $I2CBUS 0x68 0x0e 0x00
sleep 1
i2cget -f -y $I2CBUS 0x68 0x0e

trap SIGINT

reboot
