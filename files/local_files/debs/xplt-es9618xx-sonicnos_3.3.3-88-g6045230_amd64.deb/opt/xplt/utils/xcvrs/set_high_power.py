import sonic_platform.platform

platform = sonic_platform.platform.Platform()
chassis = platform.get_chassis()

sfp_list = chassis.get_all_sfps()

for sfp in sfp_list:
    api = sfp.get_xcvr_api()
    api.set_lpmode(False)
    mdstate = api.get_module_state()
    apsel_dict = api.get_active_apsel_hostlane()
    print(f"mdstate={mdstate}, apsec={apsel_dict}")
